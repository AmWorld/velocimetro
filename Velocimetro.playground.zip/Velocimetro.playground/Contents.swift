//: velocimetro COURSERA

import UIKit


enum velocidades : Int {
    
    case apagado = 0
    case velocidadBaja = 20
    case velocidadMedia = 50
    case velocidadAlta = 120
    
    init (velocidadInicial : velocidades){
        self = velocidadInicial
    }
}

class Auto {
    
    var velocidad : velocidades
    
    init(){
        self.velocidad = velocidades (velocidadInicial: .apagado)
    }
    
    func cambioDeVelocidad ( )->( actual : Int, velocidadEnCadenas : String){
        
        var velocidadEscrita : String
        
        switch self.velocidad{
        case .apagado:
            velocidad = .velocidadBaja
            velocidadEscrita = "Velocidad Baja"
        case .velocidadBaja:
            velocidad = . velocidadMedia
            velocidadEscrita = "Velocidad Media"
        case .velocidadMedia:
            velocidad = .velocidadAlta
            velocidadEscrita = "Velocidad Alta"
        case .velocidadAlta:
            velocidad = .velocidadMedia
            velocidadEscrita = "Velocidad Media"
            
        }
        
        return (actual : velocidad.rawValue, velocidadEscrita)
    }
}

var auto = Auto()

print ("0, Apagado")

for contar in 1...20{
    var velocidadFinal = auto.cambioDeVelocidad()
    print("\(velocidadFinal.actual), \(velocidadFinal.velocidadEnCadenas)")
}



